document.addEventListener("DOMContentLoaded", () => {
    const backupList = document.getElementById("backup-list");
    const logins1h = document.getElementById("logins-1h");
    const logins12h = document.getElementById("logins-12h");
    const logins24h = document.getElementById("logins-24h");
    const logins1w = document.getElementById("logins-1w");
    const backupMessage = document.getElementById("backup-message"); // Status message for backups
    
    const token = localStorage.getItem('token');
  
    if (!token) {
        window.location.href = "index.html";
        return;
    }
  
    function fetchWithAuth(url) {
        return fetch(url, {
            headers: { Authorization: `Bearer ${token}` }
        }).then(res => res.json());
    }
  
    // Fetch backups
    fetchWithAuth('http://localhost:3000/backups')
        .then(data => {
            backupList.innerHTML = data.backups.map(file => `<li>${file}</li>`).join('');
        })
        .catch(() => {
            backupList.innerHTML = "<li>Erro ao carregar backups.</li>";
        });
  
    // Fetch logs
    fetchWithAuth('http://localhost:3000/logs')
        .then(data => {
            logins1h.textContent = data.logs.length;
            logins12h.textContent = data.logs.length * 2; // Placeholder logic
            logins24h.textContent = data.logs.length * 3;
            logins1w.textContent = data.logs.length * 5;
        })
        .catch(() => {
            logins1h.textContent = "Erro";
            logins12h.textContent = "Erro";
            logins24h.textContent = "Erro";
            logins1w.textContent = "Erro";
        });
  
    // Backup trigger button
    const backupButton = document.getElementById("trigger-backup");
    if (backupButton) {
        backupButton.addEventListener("click", async () => {
            backupMessage.textContent = "Executando backup...";
            backupMessage.style.color = "blue";
  
            try {
                const response = await fetch('http://localhost:3000/backup', {
                    method: 'POST',
                    headers: { 
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    }
                });
  
                const data = await response.json();
  
                if (response.ok) {
                    backupMessage.textContent = "Backup concluído com sucesso!";
                    backupMessage.style.color = "green";
                } else {
                    backupMessage.textContent = "Erro ao executar backup.";
                    backupMessage.style.color = "red";
                }
            } catch (error) {
                backupMessage.textContent = "Erro ao conectar ao servidor.";
                backupMessage.style.color = "red";
            }
        });
    }
  });
